﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace STSVGRender
{
    public class SVGElementCollection : IList
    {
        public int Count { get; private set; }
        private int m_capacity;
        private SVGElement[] m_arr;
        private SVGElement m_parent;

        public SVGElementCollection() : this(null, 0) { }

        public SVGElementCollection(int capacity) : this(null, capacity) { }

        public SVGElementCollection(SVGElement parent) : this(parent, 0) { }

        public SVGElementCollection(SVGElement parent, int capacity) {
            m_parent = parent;
            m_arr = new SVGElement[capacity];
            m_capacity = capacity;
        }

        private void EnsureSpace(int nCount) {
            if (this.Count + 1 <= m_arr.Length) {
                return;
            }
            int nMax = Math.Max(m_arr.Length << 1, this.Count + 1);
            SVGElement[] temp = new SVGElement[nMax];
            Array.Copy(m_arr, temp, this.Count);
            m_arr = temp;
        }
        // [interface] ================================================================
        int IList.Add(object value) {
            return this.Add((SVGElement)value);
        }

        public int Add(SVGElement ele) {
            int nIndex = this.IndexOf(ele);
            if (nIndex >= 0) {
                return nIndex;
            }
            this.EnsureSpace(1);
            m_arr[this.Count++] = ele;
            ele.Parent = m_parent;
            return this.Count - 1;
        }

        public void Clear() {
            m_arr = new SVGElement[m_capacity];
            this.Count = 0;
        }

        bool IList.Contains(object value) {
            return this.Contains((SVGElement)value);
        }

        public bool Contains(SVGElement ele) {
            return m_arr.Contains(ele);
        }

        int IList.IndexOf(object value) {
            return this.IndexOf((SVGElement)value);
        }

        public int IndexOf(SVGElement ele) {
            return Array.IndexOf(m_arr, ele, 0, this.Count);
        }

        void IList.Insert(int nIndex, object value) {
            this.Insert(nIndex, (SVGElement)value);
        }

        public void Insert(int nIndex, SVGElement ele) {
            if (this.IndexOf(ele) >= 0) {
                return;
            }
            this.EnsureSpace(1);
            for (int i = this.Count; i > nIndex; i--) {
                m_arr[i] = m_arr[i - 1];
            }
            m_arr[nIndex] = ele;
            this.Count++;
        }

        public bool IsFixedSize {
            get { return false; }
        }

        public bool IsReadOnly {
            get { return false; }
        }

        void IList.Remove(object value) {
            this.Remove((SVGElement)value);
        }

        public void Remove(SVGElement ele) {
            int nIndex = this.IndexOf(ele);
            if (nIndex < 0) {
                return;
            }
            this.RemoveAt(nIndex);
        }

        public void RemoveAt(int index) {
            for (int i = index; i < this.Count; i++) {
                m_arr[i] = m_arr[i + 1];
            }
            this.Count--;
        }

        object IList.this[int nIndex] {
            get {
                return this[nIndex];
            }
            set {
                this[nIndex] = (SVGElement)value;
            }
        }

        public SVGElement this[int nIndex] {
            get {
                if (nIndex < 0 || nIndex >= this.Count) {
                    throw new IndexOutOfRangeException();
                }
                return m_arr[nIndex];
            }
            set {
                if (nIndex < 0 || nIndex >= this.Count) {
                    throw new IndexOutOfRangeException();
                }
                m_arr[nIndex] = value;
            }
        }

        public void CopyTo(Array array, int index) {
            m_arr.CopyTo(array, index);
        }

        public bool IsSynchronized {
            get { return true; }
        }

        object ICollection.SyncRoot {
            get { return this; }
        }

        public SVGElementCollection SyncRoot {
            get { return this; }
        }

        public IEnumerator GetEnumerator() {
            for (int i = 0; i < this.Count; i++) {
                yield return m_arr[i];
            }
        }
    }
}
