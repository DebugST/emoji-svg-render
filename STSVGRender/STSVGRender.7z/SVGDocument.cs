﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Xml;
using System.Text.RegularExpressions;

namespace STSVGRender
{
    public class SVGDocument
    {
        private static Regex m_reg_style_width = new Regex(@"\bwidth\s*:\s*(\d+(?:\.\d+))");
        private static Regex m_reg_style_height = new Regex(@"\bheight\s*:\s*(\d+(?:\.\d+))");
        private static Regex m_reg_viewbox = new Regex(@"(-?\d(?:\.\d+)?)+");
        public string SourceXml { get; private set; }
        public float Width { get; set; }
        public float Height { get; set; }
        public SizeF Size {
            get { return new SizeF(this.Width, this.Height); }
            set {
                this.Width = value.Width;
                this.Height = value.Height;
            }
        }
        public RectangleF ViewBox { get; private set; }
        public SVGElementCollection Childs { get; private set; }

        public SVGDocument(RectangleF rectFViewBox) : this(rectFViewBox, rectFViewBox.Width, rectFViewBox.Height) { }

        public SVGDocument(RectangleF rectFViewBox, SizeF sizeF) : this(rectFViewBox, sizeF.Width, sizeF.Height) { }

        public SVGDocument(RectangleF rectFViewBox, float fWidth, float fHeight) {
            this.ViewBox = rectFViewBox;
            this.Width = fWidth;
            this.Height = fHeight;
            this.Childs = new SVGElementCollection();
        }

        public void Draw(DrawingTools dt, RectangleF rectF) {
            if (rectF.Width <= 0 || rectF.Height <= 0) {
                return;
            }
            var g = dt.Graphics;
            var old_g = g.Save();
            g.SetClip(rectF);
            g.TranslateTransform(rectF.X, rectF.Y);
            float xScale = 1;// rectF.Width / rectFView.Width;
            float yScale = 1;// rectF.Height / rectFView.Height;
            if (this.ViewBox.Width != 0) {
                xScale = rectF.Width / this.ViewBox.Width;
            }
            if (this.ViewBox.Height != 0) {
                yScale = rectF.Height / this.ViewBox.Height;
            }
            g.ScaleTransform(xScale, yScale);
            g.TranslateTransform(0 - this.ViewBox.X, 0 - this.ViewBox.Y);
            foreach (SVGElement ele in this.Childs) {
                ele.Draw(dt);
            }
            g.Restore(old_g);
        }

        public static SVGDocument FromXmlString(string strXml) {
            XmlDocument xml = new XmlDocument();
            xml.LoadXml(strXml);
            return SVGDocument.FromXmlDocument(xml);
        }

        public static SVGDocument FromXmlDocument(XmlDocument xmlDocument) {
            var ele = xmlDocument.DocumentElement;
            if (ele == null || ele.Name != "svg") {
                throw new ArgumentException("Invalid svg document");
            }
            float fWidth = 0F, fHeight = 0F;
            if (ele.Attributes["width"] != null) {
                fWidth = float.Parse(ele.Attributes["width"].Value);
            }
            if (ele.Attributes["height"] != null) {
                fHeight = float.Parse(ele.Attributes["height"].Value);
            }
            if (ele.Attributes["style"] != null) {
                string strStyle = ele.Attributes["style"].Value;
                Match m = m_reg_style_width.Match(strStyle);
                if (m.Success) {
                    fWidth = float.Parse(m.Groups[1].Value);
                }
                m = m_reg_style_height.Match(strStyle);
                if (m.Success) {
                    fHeight = float.Parse(m.Groups[1].Value);
                }
            }
            RectangleF rectFView = RectangleF.Empty;
            if (ele.Attributes["viewBox"] != null) {
                MatchCollection ms = m_reg_viewbox.Matches(ele.Attributes["viewBox"].Value);
                if (ms.Count == 4) {
                    rectFView.X = float.Parse(ms[0].Value);
                    rectFView.Y = float.Parse(ms[1].Value);
                    rectFView.Width = float.Parse(ms[2].Value);
                    rectFView.Height = float.Parse(ms[3].Value);
                }
            }
            if (rectFView == RectangleF.Empty) {
                //if (fWidth == 0 || fHeight == 0) {
                //    throw new ArgumentException("Invalid svg document(Can not get the svg size or viewBox)");
                //} else {
                rectFView.Width = fWidth;
                rectFView.Height = fHeight;
                //}
            } else {
                if (fWidth == 0) {
                    fWidth = rectFView.Width;
                }
                if (fHeight == 0) {
                    fHeight = rectFView.Height;
                }
            }
            SVGDocument svg = new SVGDocument(rectFView, fWidth, fHeight);
            foreach (XmlNode node in ele.ChildNodes) {
                if (node.Name[0] == '#') {
                    continue;
                }
                svg.Childs.Add(SVGDocument.GetElements(node));
            }
            return svg;
        }

        private static SVGElement GetElements(XmlNode node) {
            SVGElement ele = null;
            switch (node.LocalName) {
                case "g":
                    ele = new SVGG(node);
                    foreach (XmlNode subNode in node.ChildNodes) {
                        if (subNode.LocalName[0] == '#') {
                            continue;
                        }
                        ele.Childs.Add(SVGDocument.GetElements(subNode));
                    }
                    break;
                case "rect":
                    return new SVGRect(node);
                case "line":
                    return new SVGLine(node);
                case "polyline":
                    return new SVGPolyline(node);
                case "polygon":
                    return new SVGPolygon(node);
                case "circle":
                    return new SVGCircle(node);
                case "ellipse":
                    return new SVGEllipse(node);
                case "path":
                    return new SVGPath(node);
            }
            return ele;
        }
    }
}
