﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing.Drawing2D;
using System.Xml;

namespace STSVGRender
{
    public class SVGG : SVGElement
    {
        public override bool AllowChildElements {
            get { return true; }
        }
        public override bool AllowFill {
            get { return false; }
        }
        public SVGG() : base(null) {
            this.Name = "g";
        }
        public SVGG(XmlNode node) : base(node) { }

        protected override void OnInitXmlAttributes(string strKey,string strValue) { }

        protected override GraphicsPath GetElementPath() {
            return null;
        }
    }
}
