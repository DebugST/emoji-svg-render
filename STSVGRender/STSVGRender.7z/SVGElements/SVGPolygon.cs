﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Drawing.Drawing2D;
using System.Xml;

namespace STSVGRender
{
    public class SVGPolygon : SVGElement
    {
        private static Regex m_reg_num = new Regex(@"-?(\.\d+|\d+(\.\d+)?)");
        public override bool AllowChildElements {
            get { return false; }
        }
        public override bool AllowFill {
            get { return true; }
        }
        private string _Points;
        public string Points {
            get { return _Points; }
            set {
                m_points = this.SetPoints(value);
                string[] str_arr = new string[m_points.Length];
                for (int i = 0; i < m_points.Length; i++) {
                    str_arr[i] = m_points[i].X + "," + m_points[i].Y;
                }
                _Points = string.Join(" ", str_arr);
            }
        }
        private PointF[] m_points;

        public SVGPolygon(XmlNode node) : base(node) { }
        public SVGPolygon(string strPoints)
            : base(null) {
            this.Name = "polygon";
            this.Points = strPoints;
        }
        public SVGPolygon(PointF[] points)
            : base(null) {
            this.Name = "polygon";
            m_points = new PointF[points.Length];
            string[] str_arr = new string[m_points.Length];
            for (int i = 0; i < m_points.Length; i++) {
                m_points[i] = points[i];
                str_arr[i] = m_points[i].X + "," + m_points[i].Y;
            }
            _Points = string.Join(" ", str_arr);
        }

        protected override void OnInitXmlAttributes(string strKey, string strValue) {
            switch (strKey) {
                case "points":
                    this.Points = strValue;
                    break;
            }
        }

        protected override GraphicsPath GetElementPath() {
            if (m_points == null || m_points.Length < 1) {
                return null;
            }
            GraphicsPath gp = new GraphicsPath();
            gp.AddPolygon(m_points);
            return gp;
        }

        private PointF[] SetPoints(string strPoints) {
            var ms = m_reg_num.Matches(strPoints);
            PointF[] ptFs = new PointF[ms.Count / 2];
            for (int i = 0, j = 0; i < ms.Count; i += 2, j++) {
                ptFs[j].X = float.Parse(ms[i].Value);
                ptFs[j].Y = float.Parse(ms[i + 1].Value);
            }
            return ptFs;
        }
    }
}
