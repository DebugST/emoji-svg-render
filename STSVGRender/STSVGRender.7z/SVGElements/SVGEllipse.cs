﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing.Drawing2D;
using System.Xml;

namespace STSVGRender
{
    public class SVGEllipse : SVGElement
    {
        public override bool AllowChildElements {
            get { return false; }
        }
        public override bool AllowFill {
            get { return true; }
        }
        public float CX { get; set; }
        public float CY { get; set; }
        public float RX { get; set; }
        public float RY { get; set; }

        public SVGEllipse(XmlNode node) : base(node) { }
        public SVGEllipse(float cx, float cy, float rx, float ry) : base(null) {
            this.Name = "ellipse";
            this.CX = cx;
            this.CY = cy;
            this.RX = rx;
            this.RY = ry;
        }

        protected override void OnInitXmlAttributes(string strKey, string strValue) {
            switch (strKey) { 
                case "cx":
                    this.CX = float.Parse(strValue);
                    break;
                case "cy":
                    this.CY = float.Parse(strValue);
                    break;
                case "rx":
                    this.RX = float.Parse(strValue);
                    break;
                case "ry":
                    this.RY = float.Parse(strValue);
                    break;
            }
        }

        protected override GraphicsPath GetElementPath() {
            GraphicsPath gp = new GraphicsPath();
            gp.AddEllipse(this.CX - this.RX, this.CY - this.RY, this.RX * 2, this.RY * 2);
            return gp;
        }
    }
}
