﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing.Drawing2D;
using System.Xml;
using System.Drawing;

namespace STSVGRender
{
    public class SVGLine : SVGElement
    {
        public override bool AllowChildElements {
            get { return false; }
        }
        public override bool AllowFill {
            get { return false; }
        }
        public float X1 { get; set; }
        public float Y1 { get; set; }
        public float X2 { get; set; }
        public float Y2 { get; set; }

        public SVGLine(XmlNode node) : base(node) { }
        public SVGLine() : this(0, 0, 0, 0) { }
        public SVGLine(float x1, float y1, float x2, float y2)
            : base(null) {
            this.Name = "line";
            this.X1 = x1;
            this.Y1 = y1;
            this.X2 = x2;
            this.Y2 = y2;
        }

        protected override void OnInitXmlAttributes(string strKey, string strValue) {
            switch (strKey) {
                case "x1":
                    this.X1 = float.Parse(strValue);
                    break;
                case "y1":
                    this.Y1 = float.Parse(strValue);
                    break;
                case "x2":
                    this.X2 = float.Parse(strValue);
                    break;
                case "y2":
                    this.Y2 = float.Parse(strValue);
                    break;
            }
        }

        protected override GraphicsPath GetElementPath() {
            GraphicsPath gp = new GraphicsPath();
            gp.AddLine(this.X1, this.Y1, this.X2, this.Y2);
            return gp;
        }
    }
}
