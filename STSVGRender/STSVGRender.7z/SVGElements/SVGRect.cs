﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Drawing.Drawing2D;
using System.Drawing;

namespace STSVGRender
{
    public class SVGRect : SVGElement
    {
        public override bool AllowChildElements {
            get { return false; }
        }
        public override bool AllowFill {
            get { return true; }
        }
        public float X { get; set; }
        public float Y { get; set; }
        public float Width { get; set; }
        public float Height { get; set; }
        public float RX { get; set; }
        public float RY { get; set; }

        public SVGRect(XmlNode node) : base(node) { }

        public SVGRect() : this(0, 0, 0, 0, 0, 0) { }
        public SVGRect(float x, float y, float width, float height) : this(x, y, width, height, 0, 0) { }
        public SVGRect(float x, float y, float width, float height, float rx, float ry)
            : base(null) {
            this.Name = "rect";
            this.X = x;
            this.Y = y;
            this.Width = width;
            this.Height = height;
            this.RX = rx;
            this.RY = ry;
        }

        protected override void OnInitXmlAttributes(string strKey,string strValue) {
                switch (strKey) {
                    case "x":
                        this.X = float.Parse(strValue);
                        break;
                    case "y":
                        this.Y = float.Parse(strValue);
                        break;
                    case "rx":
                        this.RX = float.Parse(strValue);
                        break;
                    case "ry":
                        this.RY = float.Parse(strValue);
                        break;
                    case "width":
                        this.Width = float.Parse(strValue);
                        break;
                    case "height":
                        this.Height = float.Parse(strValue);
                        break;
            }
        }

        protected override GraphicsPath GetElementPath() {
            return this.GetRoundRectPath(this.X, this.Y, this.Width, this.Height, this.RX, this.RY);
        }

        private GraphicsPath GetRoundRectPath(float nX, float nY, float nWidth, float nHeight, float nRX, float nRY) {
            GraphicsPath gp = new GraphicsPath();
            if (nRX == 0 || nRY == 0) {
                gp.AddRectangle(new RectangleF(nX, nY, nWidth, nHeight));
            } else {
                nRX *= 2;
                nRY *= 2;
                if (nRX > nWidth) {
                    nRX = nWidth;
                }
                if (nRY > nHeight) {
                    nRY = nHeight;
                }
                gp.AddArc(nX, nY, nRX, nRY, 180, 90);
                gp.AddArc(nX + nWidth - nRX, nY, nRX, nRY, 270, 90);
                gp.AddArc(nX + nWidth - nRX, nY + nHeight - nRY, nRX, nRY, 0, 90);
                gp.AddArc(nX, nY + nHeight - nRY, nRX, nRY, 90, 90);
                gp.CloseFigure();
            }
            return gp;
        }
    }
}
