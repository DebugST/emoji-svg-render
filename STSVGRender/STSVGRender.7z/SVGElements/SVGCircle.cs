﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing.Drawing2D;
using System.Xml;
using System.Drawing;

namespace STSVGRender
{
    public class SVGCircle : SVGElement
    {
        public override bool AllowChildElements {
            get { return false; }
        }
        public override bool AllowFill {
            get { return true; }
        }
        public float CX { get; set; }
        public float CY { get; set; }
        public float R { get; set; }

        public SVGCircle(XmlNode node) : base(node) { }
        public SVGCircle(float cx, float cy, float r)
            : base(null) {
            this.Name = "circle";
            this.CX = cx;
            this.CY = cy;
            this.R = r;
        }

        protected override void OnInitXmlAttributes(string strKey, string strValue) {
            switch (strKey) { 
                case "cx":
                    this.CX = float.Parse(strValue);
                    break;
                case "cy":
                    this.CY = float.Parse(strValue);
                    break;
                case "r":
                    this.R = float.Parse(strValue);
                    break;
            }
        }

        protected override GraphicsPath GetElementPath() {
            GraphicsPath gp = new GraphicsPath();
            RectangleF rectF = new RectangleF(this.CX - this.R, this.CY - this.R, this.R * 2, this.R * 2);
            gp.AddEllipse(rectF);
            return gp;
        }
    }
}
