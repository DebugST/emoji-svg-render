﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Drawing.Drawing2D;

namespace STSVGRender
{
    public class SVGElementStyle
    {
        internal bool ShouldMark { get; set; }

        private float _Opacity = 1;

        public float Opacity {
            get { return _Opacity; }
            set {
                if (value < 0) {
                    value = 0;
                } else if (value > 1) {
                    value = 1;
                }
                _Opacity = value;
                this.MarkAttribute("_Opacity", "opacity", _Opacity);
            }
        }

        private float _FillOpacity = 1;

        public float FillOpacity {
            get { return _FillOpacity; }
            set {
                if (value < 0) {
                    value = 0;
                } else if (value > 1) {
                    value = 1;
                }
                _FillOpacity = value;
                this.MarkAttribute("_FillOpacity", "fill-opacity", _FillOpacity);
            }
        }

        private Color _Fill = Color.Black;
        public Color Fill {
            get { return _Fill; }
            set {
                _Fill = value;
                this.MarkAttribute("_Fill", "fill", _Fill);
            }
        }

        private FillRule _FillRule = FillRule.Nonzero;

        public FillRule FillRule {
            get { return _FillRule; }
            set {
                _FillRule = value;
                this.MarkAttribute("_FillRule", "fill-rule", _FillRule);
            }
        }

        private float _StrokeOpacity = 1;
        public float StrokeOpacity {
            get { return _StrokeOpacity; }
            set {
                if (value < 0) {
                    value = 0;
                } else if (value > 1) {
                    value = 1;
                }
                _StrokeOpacity = value;
                this.MarkAttribute("_StrokeOpacity", "stroke-opacity", _StrokeOpacity);
            }
        }

        private Color _Stroke;
        public Color Stroke {
            get { return _Stroke; }
            set {
                _Stroke = value;
                this.MarkAttribute("_Stroke", "stroke", _Stroke);
            }
        }

        private float _StrokeWidth = 1;
        public float StrokeWidth {
            get { return _StrokeWidth; }
            set {
                if (value < 0) {
                    _StrokeWidth = 0;
                }
                _StrokeWidth = value;
                this.MarkAttribute("_StrokeWidth", "stroke-width", _StrokeWidth);
            }
        }

        private float _StrokeMiterLimit = 10;
        public float StrokeMiterLimit {
            get { return _StrokeMiterLimit; }
            set {
                if (value < 0) {
                    value = 0;
                }
                _StrokeMiterLimit = value;
                this.MarkAttribute("_StrokeMiterLimit", "stroke-miterlimit", _StrokeMiterLimit);
            }
        }

        private StrokeLineCap _StrokeLineCap = StrokeLineCap.Butt;
        public StrokeLineCap StrokeLineCap {
            get { return _StrokeLineCap; }
            set {
                _StrokeLineCap = value;
                this.MarkAttribute("_StrokeLineCap", "stroke-linecap", _StrokeLineCap);
            }
        }

        private StrokeLineJoin _StrokeLineJoin = StrokeLineJoin.Miter;
        public StrokeLineJoin StrokeLineJoin {
            get { return _StrokeLineJoin; }
            set {
                _StrokeLineJoin = value;
                this.MarkAttribute("_StrokeLineJoin", "stroke-linejoin", _StrokeLineJoin);
            }
        }

        private float[] _StrokeDashArray;

        public float[] StrokeDashArray {
            get { return _StrokeDashArray; }
            set {
                _StrokeDashArray = value;
                this.MarkAttribute("_StrokeDashArray", "stroke-dasharray", _StrokeDashArray);
            }
        }

        private float _StrokeDashOffset;

        public float StrokeDashOffset {
            get { return _StrokeDashOffset; }
            set {
                _StrokeDashOffset = value;
                this.MarkAttribute("_StrokeDashOffset", "stroke-dashoffset", _StrokeDashOffset);
            }
        }

        private Matrix _Transform;

        public Matrix Transform {
            get { return _Transform; }
            set { _Transform = value; }
        }

        private Dictionary<string, AttributeInfo> m_dic_marked_attr = new Dictionary<string, AttributeInfo>();


        public static Color GetColor(string strColorCode) {
            int nR = 0, nG = 0, nB = 0, nA = 255;
            strColorCode = strColorCode.ToLower();
            try {
                if (strColorCode[0] == '#') {
                    switch (strColorCode.Length) {
                        case 4:
                        case 5:
                            nR = Convert.ToInt32(strColorCode[1].ToString() + strColorCode[1], 16);
                            nG = Convert.ToInt32(strColorCode[2].ToString() + strColorCode[2], 16);
                            nB = Convert.ToInt32(strColorCode[3].ToString() + strColorCode[3], 16);
                            if (strColorCode.Length == 5) {
                                nA = Convert.ToInt32(strColorCode[4].ToString() + strColorCode[4], 16);
                            }
                            break;
                        case 7:
                        case 9:
                            nR = Convert.ToInt32(strColorCode.Substring(1, 2), 16);
                            nG = Convert.ToInt32(strColorCode.Substring(3, 2), 16);
                            nB = Convert.ToInt32(strColorCode.Substring(5, 2), 16);
                            if (strColorCode.Length == 9) {
                                nA = Convert.ToInt32(strColorCode.Substring(7, 2), 16);
                            }
                            break;
                        default:
                            return Color.Transparent;
                    }
                    return Color.FromArgb(nA, nR, nG, nB);
                }
                if (strColorCode.StartsWith("rgb")) {
                    int nLeft = strColorCode.IndexOf('(');
                    int nRight = strColorCode.IndexOf(')');
                    string[] strs = strColorCode.Substring(nLeft + 1, nRight - nLeft - 1).Split(',');
                    if (strs.Length < 3) return Color.Transparent;
                    nR = int.Parse(strs[0]);
                    nG = int.Parse(strs[1]);
                    nB = int.Parse(strs[2]);
                    if (strs.Length == 4) {
                        nA = (int)(255 * float.Parse(strs[3][0] == '.' ? "0" + strs[3] : strs[3]));
                    }
                    return Color.FromArgb(nA, nR, nG, nB);
                }
                return Color.FromName(strColorCode);
            } catch {
                return Color.FromArgb(nA, nR, nG, nB); ;
            }
        }

        public static StrokeLineCap GetStrokeLineCap(string strValue) {
            switch (strValue) {
                case "butt":
                    return StrokeLineCap.Butt;
                case "round":
                    return StrokeLineCap.Round;
                case "square":
                    return StrokeLineCap.Square;
                case "inherit":
                    return StrokeLineCap.Inherit;
            }
            return StrokeLineCap.Butt;
        }

        public static StrokeLineJoin GetStrokeLineJoin(string strValue) {
            switch (strValue) {
                case "miter":
                    return StrokeLineJoin.Miter;
                case "round":
                    return StrokeLineJoin.Round;
                case "bevel":
                    return StrokeLineJoin.Bevel;
                case "inherit":
                    return StrokeLineJoin.Inherit;
            }
            return StrokeLineJoin.Miter;
        }

        public static FillRule GetFillRule(string strValue) {
            return strValue == "evenodd" ? FillRule.Evenodd : FillRule.Nonzero;
        }

        public static Matrix GetTransform(string strValue) {
            Regex reg_transform = new Regex(@"(rotate|scale|scaleX|scaleY|skew|skewX|skewY|translate|translateX|translateY|matrix)(\(.*?\))");
            Regex reg_number = new Regex(@"-?(\.\d+|\d+(\.\d+)?)");
            Matrix matrix = new Matrix();
            float tempF1 = 0, tempF2 = 0;
            foreach (Match m in reg_transform.Matches(strValue)) {
                var ms_num = reg_number.Matches(m.Groups[2].Value);
                if (ms_num.Count < 1) {
                    continue;
                }
                tempF1 = _f(ms_num[0].Value);
                tempF2 = ms_num.Count > 1 ? _f(ms_num[1].Value) : tempF1;
                switch (m.Groups[1].Value) {
                    case "rotate":
                        matrix.Rotate(_f(ms_num[0].Value));
                        break;
                    case "scale":
                        matrix.Scale(tempF1, tempF2);
                        break;
                    case "scaleX":
                        matrix.Scale(_f(ms_num[0].Value), 1);
                        break;
                    case "scaleY":
                        matrix.Scale(1, _f(ms_num[0].Value));
                        break;
                    case "skew":
                        tempF1 = (float)Math.Tan(tempF1 / 180 * Math.PI);
                        tempF2 = (float)Math.Tan(tempF2 / 180 * Math.PI);
                        matrix.Shear(tempF1, tempF2);
                        break;
                    case "skewX":
                        tempF1 = (float)Math.Tan(tempF1 / 180 * Math.PI);
                        matrix.Shear(tempF1, 0);
                        break;
                    case "skewY":
                        tempF1 = (float)Math.Tan(tempF1 / 180 * Math.PI);
                        matrix.Shear(0, tempF1);
                        break;
                    case "translate":
                        matrix.Translate(tempF1, tempF2);
                        break;
                    case "translateX":
                        matrix.Translate(tempF1, 0);
                        break;
                    case "translateY":
                        matrix.Translate(0, tempF1);
                        break;
                    case "matrix":
                        if (ms_num.Count != 6) {
                            break;
                        }
                        using (Matrix m_temp = new Matrix(
                            tempF1,
                            tempF2,
                            _f(ms_num[2].Value),
                            _f(ms_num[3].Value),
                            _f(ms_num[4].Value),
                            _f(ms_num[5].Value))) {
                            matrix.Multiply(m_temp);
                        }
                        break;
                }
            }
            return matrix;
        }

        private static float _f(string strValue) {
            return float.Parse(strValue);
        }
        //===============================================
        private void MarkAttribute(string strFieldName, string strAttrName, object value) {
            if (!this.ShouldMark) {
                return;
            }
            AttributeInfo attr = new AttributeInfo(strFieldName, strAttrName, value);
            if (m_dic_marked_attr.ContainsKey(attr.Name)) {
                m_dic_marked_attr[attr.Name] = attr;
            } else {
                m_dic_marked_attr.Add(attr.Name, attr);
            }
        }

        public Dictionary<string, AttributeInfo>.KeyCollection GetMarkedKeys() {
            return m_dic_marked_attr.Keys;
        }

        public AttributeInfo GetMarkedAttribute(string strName) {
            return m_dic_marked_attr[strName];
        }

        public void CopyAllAttributeFromStyle(SVGElementStyle style) {
            Type t = this.GetType();
            foreach (PropertyInfo pi in t.GetProperties()) {
                pi.SetValue(this, pi.GetValue(style, null), null);
            }
            m_dic_marked_attr.Clear();
            foreach (var key in style.GetMarkedKeys()) {
                m_dic_marked_attr.Add(key, style.GetMarkedAttribute(key));
            }
        }

        public void CopyMarkedAttributeFromStyle(SVGElementStyle style) {
            this.CopyMarkedAttributeFromStyle(style, false, false);
        }

        public void CopyMarkedAttributeFromStyle(SVGElementStyle style, bool bMarkedSelf, bool bIgnoreOwnMarkedValue) {
            Type t = this.GetType();
            foreach (var v in style.GetMarkedKeys()) {
                if (!bIgnoreOwnMarkedValue && m_dic_marked_attr.ContainsKey(v)) {
                    continue;
                }
                var attr = style.GetMarkedAttribute(v);
                if (bMarkedSelf) {
                    var p = t.GetProperty(attr.Name.Substring(1));
                    p.SetValue(this, attr.Value, null);
                } else {
                    var p = t.GetField(attr.Name, BindingFlags.NonPublic | BindingFlags.Instance);
                    p.SetValue(this, attr.Value);
                }
            }
        }
    }

    public struct AttributeInfo
    {
        internal string Name;       // Field name in code
        public string StyleName;    // Style attribute name
        public object Value;        // Style attribute value

        public AttributeInfo(string strName, string strStyleName, object value) {
            this.Name = strName;
            this.StyleName = strStyleName;
            this.Value = value;
        }

        public override string ToString() {
            return "[" + this.Name + "(" + this.StyleName + ")]: " + this.Value;
        }
    }

    public enum StrokeLineCap
    {
        Butt, Round, Square, Inherit
    }

    public enum StrokeLineJoin
    {
        Miter, MiterClip, Round, Bevel, Inherit
    }

    public enum FillRule
    {
        Nonzero, Evenodd
    }
}
