﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml;
using System.Text.RegularExpressions;

namespace STSVGRender
{
    public abstract class SVGElement
    {
        private static Regex m_reg_num = new Regex(@"-?(\.\d+|\d+(\.\d+)?)");
        private static Regex m_reg_style = new Regex(@"([a-zA-Z][a-zA-z0-9\-]*)\s?:\s*(.*?);");
        public abstract bool AllowChildElements { get; }
        public abstract bool AllowFill { get; }
        //public abstract bool AllowDraw { get; }
        public string Name { get; internal set; }
        //public string ID { get; set; }
        //public string Class { get; set; }
        public string SourceXml { get; private set; }
        public SVGElement Parent { get; internal set; }
        public SVGElementCollection Childs { get; internal set; }
        public SVGElementStyle Style { get; private set; }

        //public string Style { get; set; }

        public SVGElement(XmlNode node) {
            this.Name = node.LocalName;
            this.SourceXml = node.InnerXml;
            this.Style = new SVGElementStyle();
            this.Childs = new SVGElementCollection(this);
            if (node != null) {
                Dictionary<string, string> dic = new Dictionary<string, string>();
                foreach (XmlAttribute attr in node.Attributes) {
                    dic.Add(attr.Name, attr.Value);
                }
                this.Style.ShouldMark = false;
                this.OnInitDefaultAttribute();
                this.Style.ShouldMark = true;
                this.SetStyle(dic);
            }
        }
        // [static] ===========================================
        public static T FromXmlNode<T>(XmlNode node) {
            var svg = SVGElement.FromXmlNode(node);
            return (T)(object)svg;
        }

        public static SVGElement FromXmlNode(XmlNode node) {
            if (node == null) {
                return null;
            }
            switch (node.Name) {
                case "rect":
                    break;
            }
            return null;
        }
        // [public] ===========================================
        public void Draw(DrawingTools dt) {
            this.OnDraw(dt);
        }
        // [protected] ========================================
        protected virtual void OnDraw(DrawingTools dt) {
            GraphicsPath gp = null;
            this.OnInheritStyle();
            var style = this.Style;
            if (this.AllowFill && this.Style.Fill.A != 0 && style.Opacity != 0 && style.FillOpacity != 0) {
                if ((gp = this.GetPath()) != null) {
                    dt.Brush.Color = Color.FromArgb((int)(style.Fill.A * style.Opacity * style.FillOpacity * style.Fill.A / 255), style.Fill);
                    dt.Graphics.FillPath(dt.Brush, gp);
                }
            } 
            if (this.Style.Stroke.A != 0 && style.Opacity != 0 && style.StrokeOpacity != 0 && this.Style.StrokeWidth > 0) {
                if (gp != null || (gp = this.GetPath()) != null) {
                    this.OnSetPen(dt.Pen);
                    dt.Graphics.DrawPath(dt.Pen, gp);
                }
            }
            if (this.AllowChildElements) {
                foreach (SVGElement ele in this.Childs) {
                    ele.OnDraw(dt);
                }
            }
            if (gp != null) {
                gp.Dispose();
            }
        }

        protected virtual void OnSetPen(Pen p) {
            var style = this.Style;
            p.Color = Color.FromArgb((int)(style.Stroke.A * style.Opacity * style.StrokeOpacity * style.Stroke.A / 255), style.Stroke);
            p.Width = style.StrokeWidth;
            if (style.StrokeLineCap == StrokeLineCap.Inherit && this.Parent != null) {
                style.StrokeLineCap = this.Parent.Style.StrokeLineCap;
            } else {
                switch (this.Style.StrokeLineCap) {
                    case StrokeLineCap.Butt:
                        p.StartCap = LineCap.NoAnchor;
                        p.EndCap = LineCap.NoAnchor;
                        break;
                    case StrokeLineCap.Round:
                        p.StartCap = LineCap.Round;
                        p.EndCap = LineCap.Round;
                        break;
                    case StrokeLineCap.Square:
                        p.StartCap = LineCap.Square;
                        p.EndCap = LineCap.Square;
                        break;
                }
            }
            if (style.StrokeLineJoin == STSVGRender.StrokeLineJoin.Inherit && this.Parent != null) {
                style.StrokeLineJoin = this.Parent.Style.StrokeLineJoin;
            } else {
                switch (this.Style.StrokeLineJoin) {
                    case StrokeLineJoin.Miter:
                        p.LineJoin = LineJoin.Miter;
                        break;
                    case StrokeLineJoin.MiterClip:
                        p.LineJoin = LineJoin.MiterClipped;
                        break;
                    case StrokeLineJoin.Bevel:
                        p.LineJoin = LineJoin.Bevel;
                        break;
                    case StrokeLineJoin.Round:
                        p.LineJoin = LineJoin.Round;
                        break;
                }
            }
            p.MiterLimit = style.StrokeMiterLimit;
            if (style.StrokeDashArray != null && style.StrokeDashArray.Length > 0) {
                if (p.Width > 0) {
                    int nLen = style.StrokeDashArray.Length;
                    float[] temp = new float[nLen % 2 == 0 ? nLen : nLen << 1];
                    for (int i = 0; i < temp.Length; i++) {
                        temp[i] = style.StrokeDashArray[i % style.StrokeDashArray.Length] / p.Width;
                    }
                    p.DashPattern = temp;
                }
            }
        }

        protected virtual void OnInheritStyle() {
            Stack<SVGElement> stack = new Stack<SVGElement>();
            SVGElement temp = this.Parent;
            while (temp != null) {
                stack.Push(temp);
                temp = temp.Parent;
            }
            while (stack.Count != 0) {
                this.Style.CopyMarkedAttributeFromStyle(stack.Pop().Style);
            }
        }

        protected virtual void OnInitDefaultAttribute() { }

        protected abstract void OnInitXmlAttributes(string strKey, string strValue);

        protected abstract GraphicsPath GetElementPath();
        // [private] ==========================================
        private GraphicsPath GetPath() {
            var gp = this.GetElementPath();
            if (gp != null) {
                gp.FillMode = this.Style.FillRule == FillRule.Evenodd ? FillMode.Alternate : FillMode.Winding;
                if (this.Style.Transform != null) {
                    gp.Transform(this.Style.Transform);//TODO :from parent;
                }
            }
            return gp;
        }
        private void SetStyle(Dictionary<string, string> dic) {
            var style = this.Style;
            string strStyle = null;
            foreach (var v in dic) {
                switch (v.Key) {
                    case "style":
                        strStyle = v.Value;
                        break;
                    //case "id":
                    //    this.ID = v.Value;
                    //    break;
                    //case "class":
                    //    this.Class = v.Value;
                    //    break;
                    case "opacity":
                        style.Opacity = float.Parse(v.Value);
                        break;
                    case "fill":
                        style.Fill = SVGElementStyle.GetColor(v.Value);
                        break;
                    case "fill-opacity":
                        style.FillOpacity = float.Parse(v.Value);
                        break;
                    case "fill-rule":
                        style.FillRule = SVGElementStyle.GetFillRule(v.Value);
                        break;
                    case "stroke":
                        style.Stroke = SVGElementStyle.GetColor(v.Value);
                        break;
                    case "stroke-opacity":
                        style.StrokeOpacity = float.Parse(v.Value);
                        break;
                    case "stroke-width":
                        style.StrokeWidth = float.Parse(v.Value);
                        break;
                    case "stroke-miterlimit":
                        style.StrokeMiterLimit = float.Parse(v.Value);
                        break;
                    case "stroke-linecap":
                        style.StrokeLineCap = SVGElementStyle.GetStrokeLineCap(v.Value);
                        break;
                    case "stroke-linejoin":
                        style.StrokeLineJoin = SVGElementStyle.GetStrokeLineJoin(v.Value);
                        break;
                    case "stroke-dasharray":
                        var ms = m_reg_num.Matches(v.Value);
                        style.StrokeDashArray = new float[ms.Count];
                        for (int i = 0; i < ms.Count; i++) {
                            style.StrokeDashArray[i] = float.Parse(ms[i].Value);
                        }
                        break;
                    case "stroke-dashoffset":
                        style.StrokeDashOffset = float.Parse(v.Value);
                        break;
                    case "transform":
                        style.Transform = SVGElementStyle.GetTransform(v.Value);
                        break;

                }
                this.OnInitXmlAttributes(v.Key, v.Value);
            }
            dic = new Dictionary<string, string>();
            if (!string.IsNullOrEmpty(strStyle)) {
                foreach (Match m in m_reg_style.Matches(strStyle)) {
                    if (!dic.ContainsKey(m.Groups[1].Value)) {
                        dic.Add(m.Groups[1].Value, m.Groups[2].Value);
                    }
                }
                this.SetStyle(dic);
            }
        }
    }
}
